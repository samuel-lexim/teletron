<?php 
namespace Ves\MadeInKorea\Block;
 
class MadeInKorea extends \Magento\Framework\View\Element\Template
{
	public function _prepareLayout()
	{
		return parent::_prepareLayout();
	}
}
 